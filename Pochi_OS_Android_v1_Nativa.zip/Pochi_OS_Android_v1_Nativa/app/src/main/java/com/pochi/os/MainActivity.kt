package com.pochi.os

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity: Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val t = TextView(this)
  t.text = "🐶 Pochi OS\n\nGéminis IA\n📶 Wi-Fi\n📁 Espacios"
  t.textSize = 24f
  setContentView(t)
 }
}
